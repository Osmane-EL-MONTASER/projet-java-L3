Afin d'exécuter notre programme, exécutez la commande suivante depuis Projet Java Pirates Console Version :
java -jar projet_java_console.jar cheminVersEquipage